import {
  collection, addDoc, updateDoc, deleteDoc,
  doc, getDocs, query, orderBy, limit,
  serverTimestamp, Timestamp, where
} from "firebase/firestore";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { db, storage } from "./firebase";

export interface Article {
  id?: string;
  title: string;
  excerpt: string;
  content: string;
  category: string;
  tags: string[];
  imageUrl: string;
  author: { name: string; avatarUrl: string };
  date: string;
  readTime: string;
  status: "published" | "draft" | "scheduled";
  scheduledAt?: string;
  metaTitle: string;
  metaDescription: string;
  hashtags: string[];
  views?: number;
  createdAt?: Timestamp;
}

// Estimate read time
export function estimateReadTime(content: string): string {
  const words = content.replace(/<[^>]+>/g, "").split(/\s+/).length;
  const minutes = Math.ceil(words / 200);
  return `${minutes} min read`;
}

// Fetch all published articles
export async function getPublishedArticles(limitCount = 20): Promise<Article[]> {
  const q = query(
    collection(db, "articles"),
    where("status", "==", "published"),
    orderBy("createdAt", "desc"),
    limit(limitCount)
  );
  const snap = await getDocs(q);
  return snap.docs.map(d => ({ id: d.id, ...d.data() } as Article));
}

// Fetch all articles (admin)
export async function getAllArticles(): Promise<Article[]> {
  const q = query(collection(db, "articles"), orderBy("createdAt", "desc"));
  const snap = await getDocs(q);
  return snap.docs.map(d => ({ id: d.id, ...d.data() } as Article));
}

// Create article
export async function createArticle(article: Omit<Article, "id" | "createdAt">): Promise<string> {
  const docRef = await addDoc(collection(db, "articles"), {
    ...article,
    views: 0,
    createdAt: serverTimestamp(),
  });
  return docRef.id;
}

// Update article
export async function updateArticle(id: string, data: Partial<Article>): Promise<void> {
  await updateDoc(doc(db, "articles", id), data);
}

// Delete article
export async function deleteArticle(id: string): Promise<void> {
  await deleteDoc(doc(db, "articles", id));
}

// Upload image to Firebase Storage
export async function uploadImage(file: File): Promise<string> {
  const r = ref(storage, `images/${Date.now()}-${file.name}`);
  await uploadBytes(r, file);
  return getDownloadURL(r);
}

// Increment view count
export async function incrementViews(id: string, current: number): Promise<void> {
  await updateDoc(doc(db, "articles", id), { views: current + 1 });
}
