// Claude AI Integration — Auto Blog & SEO Generator

export interface GeneratedBlog {
  title: string;
  excerpt: string;
  content: string;
  category: string;
  tags: string[];
  metaTitle: string;
  metaDescription: string;
  hashtags: string[];
  imageQuery: string; // for Unsplash search
}

export async function generateBlogFromTopic(topic: string, category: string = "General"): Promise<GeneratedBlog> {
  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 1000,
      messages: [
        {
          role: "user",
          content: `You are an expert SEO blogger. Write a complete, Google-ranked blog post about: "${topic}" in category: "${category}".

Return ONLY valid JSON (no markdown, no backticks):
{
  "title": "compelling SEO title under 60 chars",
  "excerpt": "engaging 2-sentence summary under 160 chars",
  "content": "full blog post HTML with <h2>, <p>, <ul> tags, minimum 600 words, informative and engaging",
  "category": "${category}",
  "tags": ["tag1","tag2","tag3","tag4","tag5"],
  "metaTitle": "SEO meta title under 60 chars",
  "metaDescription": "meta description under 160 chars",
  "hashtags": ["#hashtag1","#hashtag2","#hashtag3","#hashtag4","#hashtag5"],
  "imageQuery": "3-word Unsplash search query for hero image"
}`
        }
      ]
    })
  });

  const data = await response.json();
  const text = data.content?.map((c: any) => c.text || "").join("") || "{}";
  
  try {
    const clean = text.replace(/```json|```/g, "").trim();
    return JSON.parse(clean);
  } catch {
    return {
      title: topic,
      excerpt: `An insightful article about ${topic}.`,
      content: `<h2>About ${topic}</h2><p>Content generation encountered an issue. Please try again.</p>`,
      category,
      tags: [topic.toLowerCase()],
      metaTitle: topic,
      metaDescription: `Read about ${topic} on InkVault.`,
      hashtags: [`#${topic.replace(/\s+/g, "")}`],
      imageQuery: topic.split(" ").slice(0, 3).join(" "),
    };
  }
}

export async function generateDailyTrendingBlogs(): Promise<{ topic: string; category: string }[]> {
  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 1000,
      messages: [
        {
          role: "user",
          content: `Today is ${new Date().toDateString()}. List 5 currently trending global topics that would make excellent, high-traffic blog posts for a premium content website. Focus on topics in Technology, Culture, Science, Lifestyle, Finance.

Return ONLY valid JSON array (no markdown):
[
  {"topic": "specific trending topic title", "category": "Category"},
  {"topic": "specific trending topic title", "category": "Category"},
  {"topic": "specific trending topic title", "category": "Category"},
  {"topic": "specific trending topic title", "category": "Category"},
  {"topic": "specific trending topic title", "category": "Category"}
]`
        }
      ]
    })
  });

  const data = await response.json();
  const text = data.content?.map((c: any) => c.text || "").join("") || "[]";
  
  try {
    const clean = text.replace(/```json|```/g, "").trim();
    return JSON.parse(clean);
  } catch {
    return [
      { topic: "The Future of Artificial Intelligence in 2025", category: "Technology" },
      { topic: "Sustainable Living Trends Reshaping Modern Culture", category: "Lifestyle" },
      { topic: "Global Economic Shifts and What They Mean for You", category: "Finance" },
    ];
  }
}

// Get a free Unsplash image URL from a search query
export function getUnsplashImage(query: string, width = 1200): string {
  const encoded = encodeURIComponent(query);
  return `https://source.unsplash.com/featured/${width}x628/?${encoded}`;
}
