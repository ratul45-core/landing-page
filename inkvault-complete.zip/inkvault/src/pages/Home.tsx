import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Helmet } from "react-helmet-async";
import { ArrowRight, ChevronRight, Mail, BookOpen, Star, ShieldCheck } from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { AdSlot } from "@/components/AdSlot";
import { getPublishedArticles, Article, incrementViews } from "@/lib/articles";
import { FEATURED_ARTICLES, TRENDING_ARTICLES, CATEGORIES } from "@/data/mock";
import { formatDate } from "@/lib/utils";

const fadeInUp = {
  hidden: { opacity: 0, y: 40 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.7, ease: "easeOut" } },
};
const stagger = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.12 } },
};

// Article Card Component
function ArticleCard({ article, index }: { article: Article; index: number }) {
  return (
    <motion.article
      key={article.id}
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true }}
      variants={{
        hidden: { opacity: 0, y: 30 },
        visible: { opacity: 1, y: 0, transition: { delay: index * 0.08, duration: 0.5 } },
      }}
      className="group cursor-pointer flex flex-col h-full bg-card rounded-xl overflow-hidden border border-border shadow-sm hover:shadow-xl transition-all duration-300"
    >
      <div className="relative aspect-[4/3] overflow-hidden">
        <div className="absolute top-4 left-4 z-20">
          <span className="px-3 py-1 bg-background/90 backdrop-blur-sm text-xs font-bold uppercase tracking-wider text-foreground rounded-sm">
            {article.category}
          </span>
        </div>
        <img
          src={article.imageUrl}
          alt={article.title}
          className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-700 ease-out"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
      </div>
      <div className="p-6 flex flex-col flex-1">
        <div className="flex items-center gap-2 text-xs text-muted-foreground mb-3">
          <span>{formatDate(article.date)}</span>
          <span>•</span>
          <span>{article.readTime}</span>
        </div>
        <h3 className="text-xl font-bold font-display leading-tight mb-3 group-hover:text-primary transition-colors line-clamp-2">
          {article.title}
        </h3>
        <p className="text-muted-foreground line-clamp-3 mb-6 flex-1">{article.excerpt}</p>
        <div className="flex items-center gap-3 mt-auto pt-4 border-t border-border/50">
          {article.author.avatarUrl ? (
            <img src={article.author.avatarUrl} alt={article.author.name} className="w-8 h-8 rounded-full object-cover ring-2 ring-background" />
          ) : (
            <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-primary text-sm font-bold ring-2 ring-background">
              {article.author.name?.[0] || "I"}
            </div>
          )}
          <span className="text-sm font-medium text-foreground">{article.author.name}</span>
        </div>
      </div>
    </motion.article>
  );
}

export default function Home() {
  const [liveArticles, setLiveArticles] = useState<Article[]>([]);
  const [loading, setLoading] = useState(true);
  const [email, setEmail] = useState("");
  const [subscribed, setSubscribed] = useState(false);

  useEffect(() => {
    getPublishedArticles(12)
      .then(setLiveArticles)
      .catch(() => setLiveArticles([]))
      .finally(() => setLoading(false));
  }, []);

  // Use live articles if available, fall back to mock
  const featuredArticles = liveArticles.length >= 3
    ? liveArticles.slice(0, 3)
    : FEATURED_ARTICLES as unknown as Article[];

  const latestArticles = liveArticles.length >= 3
    ? liveArticles.slice(3, 9)
    : [] as Article[];

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) { setSubscribed(true); setEmail(""); }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Helmet>
        <title>InkVault — Premium Content, Trusted Voices</title>
        <meta name="description" content="InkVault is a curated destination for insightful articles exploring culture, technology, science and lifestyle." />
        <meta property="og:title" content="InkVault — Premium Content, Trusted Voices" />
        <meta property="og:description" content="Deep dives, nuanced perspectives, and exceptional writing." />
        <meta property="og:type" content="website" />
        <meta name="twitter:card" content="summary_large_image" />
        <link rel="canonical" href="https://yourdomain.com" />
        <script type="application/ld+json">{JSON.stringify({
          "@context": "https://schema.org",
          "@type": "WebSite",
          "name": "InkVault",
          "url": "https://yourdomain.com",
          "description": "Premium content and trusted voices.",
          "potentialAction": {
            "@type": "SearchAction",
            "target": "https://yourdomain.com/search?q={search_term_string}",
            "query-input": "required name=search_term_string"
          }
        })}</script>
      </Helmet>

      <Navbar />

      <main className="flex-1 pt-24 pb-12">

        {/* HERO */}
        <section className="relative overflow-hidden pt-12 pb-20 lg:pt-24 lg:pb-32">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <motion.div initial="hidden" animate="visible" variants={stagger} className="max-w-2xl">
                <motion.div variants={fadeInUp} className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium mb-6">
                  <Star className="w-4 h-4" />
                  <span>Award-winning journalism</span>
                </motion.div>
                <motion.h1 variants={fadeInUp} className="text-5xl sm:text-6xl lg:text-7xl font-bold leading-[1.1] text-foreground mb-6">
                  Stories Worth <span className="text-primary italic">Reading.</span><br />
                  Ideas Worth <span className="text-accent italic">Sharing.</span>
                </motion.h1>
                <motion.p variants={fadeInUp} className="text-lg sm:text-xl text-muted-foreground leading-relaxed mb-8">
                  InkVault is your sanctuary for deep dives and nuanced perspectives. We curate the voices that matter, bringing clarity to a complex world.
                </motion.p>
                <motion.div variants={fadeInUp} className="flex flex-col sm:flex-row gap-4">
                  <a href="#featured" className="px-8 py-4 bg-primary text-primary-foreground font-medium rounded-sm shadow-lg shadow-primary/20 hover:shadow-xl hover:-translate-y-0.5 transition-all flex items-center justify-center gap-2">
                    Explore Articles <ArrowRight className="w-4 h-4" />
                  </a>
                  <a href="#newsletter" className="px-8 py-4 bg-background border border-border text-foreground font-medium rounded-sm hover:bg-secondary hover:border-secondary transition-all text-center">
                    Subscribe Free
                  </a>
                </motion.div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 1, delay: 0.2 }}
                className="relative lg:h-[600px] rounded-2xl overflow-hidden shadow-2xl shadow-black/10 border border-border/50"
              >
                <div className="absolute inset-0 bg-secondary/50" />
                <img
                  src={`${import.meta.env.BASE_URL}images/hero-abstract.png`}
                  alt="Abstract elegant composition"
                  className="w-full h-full object-cover relative z-10"
                  onError={e => { (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1557683316-973673baf926?auto=format&fit=crop&q=80&w=1200"; }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background/40 to-transparent z-20 mix-blend-overlay" />
              </motion.div>
            </div>
          </div>
          <div className="absolute top-0 right-0 -z-10 w-full h-full bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-primary/5 via-background to-background" />
        </section>

        {/* AD 1 */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <AdSlot type="leaderboard" />
        </div>

        {/* FEATURED */}
        <section id="featured" className="py-16 bg-secondary/30">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-100px" }} variants={fadeInUp} className="flex justify-between items-end mb-12">
              <div>
                <h2 className="text-3xl md:text-4xl font-bold">Featured Editorials</h2>
                <p className="mt-2 text-muted-foreground">Handpicked selections by our editorial board.</p>
              </div>
              <a href="#latest" className="hidden sm:flex items-center gap-1 text-primary font-medium hover:text-primary/80 transition-colors">
                View all <ChevronRight className="w-4 h-4" />
              </a>
            </motion.div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {loading
                ? Array(3).fill(0).map((_, i) => (
                  <div key={i} className="bg-card rounded-xl border border-border overflow-hidden animate-pulse">
                    <div className="aspect-[4/3] bg-muted" />
                    <div className="p-6 space-y-3">
                      <div className="h-4 bg-muted rounded w-1/3" />
                      <div className="h-6 bg-muted rounded w-5/6" />
                      <div className="h-4 bg-muted rounded w-full" />
                    </div>
                  </div>
                ))
                : featuredArticles.map((article, i) => (
                  <ArticleCard key={article.id} article={article} index={i} />
                ))
              }
            </div>
          </div>
        </section>

        {/* TOPICS & TRENDING */}
        <section id="topics" className="py-20 border-b border-border">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8">
              <div className="lg:col-span-7">
                <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeInUp}>
                  <h2 className="text-3xl font-bold mb-8">Explore by Topic</h2>
                  <div className="flex flex-wrap gap-3">
                    {CATEGORIES.map(topic => (
                      <motion.button
                        key={topic}
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        className="px-5 py-2.5 rounded-full border border-border bg-card text-foreground hover:bg-primary hover:text-primary-foreground hover:border-primary transition-colors shadow-sm font-medium"
                      >
                        {topic}
                      </motion.button>
                    ))}
                  </div>
                </motion.div>
                <div className="mt-12"><AdSlot type="responsive" /></div>
              </div>

              <div className="lg:col-span-5 lg:pl-8 lg:border-l border-border">
                <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeInUp}>
                  <div className="flex items-center gap-2 mb-8">
                    <div className="w-2 h-2 rounded-full bg-accent animate-pulse" />
                    <h2 className="text-2xl font-bold">Trending Now</h2>
                  </div>
                  <div className="flex flex-col gap-6">
                    {TRENDING_ARTICLES.map(article => (
                      <article key={article.id} className="group cursor-pointer flex gap-5 items-center">
                        <span className="text-4xl font-display font-bold text-muted-foreground/30 group-hover:text-primary/30 transition-colors w-8 text-center">
                          {article.rank}
                        </span>
                        <div className="flex-1">
                          <span className="text-xs text-accent font-bold uppercase tracking-wider mb-1 block">{article.category}</span>
                          <h4 className="text-lg font-bold font-display leading-snug group-hover:text-primary transition-colors">{article.title}</h4>
                          <span className="text-xs text-muted-foreground mt-2 block">{article.author.name} · {article.readTime}</span>
                        </div>
                        <div className="w-20 h-20 shrink-0 rounded-md overflow-hidden">
                          <img src={article.imageUrl} alt="" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" loading="lazy" />
                        </div>
                      </article>
                    ))}
                  </div>
                </motion.div>
              </div>
            </div>
          </div>
        </section>

        {/* LATEST + SIDEBAR */}
        <section id="latest" className="py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
              <div className="lg:col-span-8">
                <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeInUp} className="mb-10">
                  <h2 className="text-3xl md:text-4xl font-bold">Latest Stories</h2>
                  <div className="w-16 h-1 bg-primary mt-4" />
                </motion.div>

                {latestArticles.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    {latestArticles.map((article, i) => (
                      <motion.article
                        key={article.id}
                        initial="hidden" whileInView="visible" viewport={{ once: true }}
                        variants={{ hidden: { opacity: 0, y: 20 }, visible: { opacity: 1, y: 0, transition: { delay: i * 0.08 } } }}
                        className="group cursor-pointer flex flex-col"
                      >
                        <div className="relative aspect-[16/10] overflow-hidden rounded-xl mb-4">
                          <img src={article.imageUrl} alt={article.title} className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-500" loading="lazy" />
                        </div>
                        <span className="text-xs text-primary font-bold uppercase tracking-wider mb-2 block">{article.category}</span>
                        <h3 className="text-xl font-bold font-display leading-tight mb-2 group-hover:underline decoration-primary/50 underline-offset-4">{article.title}</h3>
                        <p className="text-muted-foreground text-sm line-clamp-2 mb-3">{article.excerpt}</p>
                        <div className="mt-auto text-xs text-muted-foreground/80 flex items-center gap-2">
                          <span className="font-medium text-foreground">{article.author.name}</span>
                          <span>•</span>
                          <span>{formatDate(article.date)}</span>
                        </div>
                      </motion.article>
                    ))}
                  </div>
                ) : (
                  <p className="text-muted-foreground">No articles yet. Check back soon or run the AI Publisher from Admin.</p>
                )}

                {latestArticles.length >= 6 && (
                  <div className="mt-12 flex justify-center">
                    <button className="px-6 py-3 border border-border rounded-sm hover:bg-secondary transition-colors font-medium">
                      Load More Articles
                    </button>
                  </div>
                )}
              </div>

              <aside className="lg:col-span-4 space-y-12">
                <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeInUp} id="about" className="bg-foreground text-background p-8 rounded-xl relative overflow-hidden">
                  <BookOpen className="w-10 h-10 text-primary mb-4 opacity-50 absolute -top-2 -right-2 transform rotate-12 scale-150" />
                  <h3 className="font-display font-bold text-2xl mb-4 relative z-10">About InkVault</h3>
                  <p className="text-background/80 leading-relaxed mb-6 relative z-10">
                    We believe in the power of well-crafted narratives. InkVault is dedicated to publishing essays, investigations, and insights that challenge the status quo and elevate discourse.
                  </p>
                  <div className="flex items-center gap-2 text-primary font-medium relative z-10 cursor-pointer hover:text-accent transition-colors">
                    <span>Read our manifesto</span> <ArrowRight className="w-4 h-4" />
                  </div>
                </motion.div>

                <div className="sticky top-24">
                  <div className="flex flex-col items-center">
                    <span className="text-[10px] text-muted-foreground uppercase tracking-widest mb-2">Advertisement</span>
                    <AdSlot type="rectangle" />
                  </div>
                  <div className="mt-12 p-6 border border-border rounded-xl bg-card text-center">
                    <ShieldCheck className="w-8 h-8 text-accent mx-auto mb-3" />
                    <h4 className="font-bold mb-2">Editorial Integrity</h4>
                    <p className="text-sm text-muted-foreground">Every piece is fact-checked and peer-reviewed by our expert editorial board.</p>
                  </div>
                </div>
              </aside>
            </div>
          </div>
        </section>

        {/* NEWSLETTER */}
        <section id="newsletter" className="py-24 bg-primary text-primary-foreground relative overflow-hidden">
          <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1557683316-973673baf926?auto=format&fit=crop&q=80&w=2000')] opacity-5 object-cover mix-blend-overlay" />
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
            <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeInUp}>
              <Mail className="w-12 h-12 mx-auto mb-6 opacity-80" />
              <h2 className="text-4xl md:text-5xl font-bold font-display mb-6">Join 50,000+ Discerning Readers</h2>
              <p className="text-xl text-primary-foreground/80 mb-10 max-w-2xl mx-auto">
                Get our flagship essays, cultural commentary, and curated recommendations delivered to your inbox every Sunday morning. No noise, just signal.
              </p>
              {subscribed ? (
                <div className="flex items-center justify-center gap-2 text-xl font-medium">
                  <ShieldCheck className="w-6 h-6" />
                  Thank you! You're on the list.
                </div>
              ) : (
                <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
                  <input
                    type="email"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    placeholder="Enter your email address"
                    className="flex-1 px-5 py-4 rounded-sm text-foreground bg-background focus:outline-none focus:ring-2 focus:ring-accent"
                    required
                  />
                  <button type="submit" className="px-8 py-4 bg-accent text-accent-foreground font-bold rounded-sm hover:bg-white transition-colors shadow-lg shadow-black/20">
                    Subscribe
                  </button>
                </form>
              )}
              <p className="mt-4 text-sm text-primary-foreground/60">We respect your privacy. Unsubscribe at any time.</p>
            </motion.div>
          </div>
        </section>

        {/* BOTTOM AD */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <AdSlot type="leaderboard" />
        </div>

      </main>

      <Footer />
    </div>
  );
}
