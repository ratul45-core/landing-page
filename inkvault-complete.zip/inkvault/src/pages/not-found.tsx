import { Link } from "wouter";
import { Feather } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-4">
      <div className="text-center">
        <div className="flex justify-center mb-6">
          <div className="bg-primary text-primary-foreground p-3 rounded-sm">
            <Feather className="w-8 h-8" />
          </div>
        </div>
        <h1 className="font-display text-6xl font-bold text-foreground mb-4">404</h1>
        <p className="text-xl text-muted-foreground mb-8">This page doesn't exist.</p>
        <Link href="/" className="px-6 py-3 bg-primary text-primary-foreground rounded-sm font-medium hover:bg-primary/90 transition-colors">
          Back to Home
        </Link>
      </div>
    </div>
  );
}
