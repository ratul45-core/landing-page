import { useState, useEffect } from "react";
import { Helmet } from "react-helmet-async";
import { signInWithEmailAndPassword, signOut, onAuthStateChanged, User } from "firebase/auth";
import { auth } from "@/lib/firebase";
import {
  getAllArticles, createArticle, updateArticle,
  deleteArticle, uploadImage, estimateReadTime, Article
} from "@/lib/articles";
import { generateBlogFromTopic, generateDailyTrendingBlogs, getUnsplashImage } from "@/lib/claude";
import {
  Feather, LogOut, Plus, Trash2, Edit3, Eye, EyeOff,
  Zap, Calendar, Globe, RefreshCw, Image, Save, X,
  TrendingUp, BarChart2, FileText, Clock, CheckCircle
} from "lucide-react";

// ─── LOGIN SCREEN ────────────────────────────────────────────────────────────
function LoginScreen({ onLogin }: { onLogin: (u: User) => void }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPass, setShowPass] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleLogin = async () => {
    setLoading(true); setError("");
    try {
      const cred = await signInWithEmailAndPassword(auth, email, password);
      onLogin(cred.user);
    } catch {
      setError("Invalid email or password.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <div className="flex items-center gap-2 justify-center mb-8">
          <div className="bg-primary text-primary-foreground p-2 rounded-sm">
            <Feather className="w-6 h-6" />
          </div>
          <span className="font-display font-bold text-3xl">InkVault</span>
        </div>
        <div className="bg-card border border-border rounded-xl p-8 shadow-xl">
          <h1 className="font-display text-2xl font-bold mb-2">Admin Access</h1>
          <p className="text-muted-foreground text-sm mb-6">Restricted area. Authorized personnel only.</p>

          {error && (
            <div className="mb-4 px-4 py-3 bg-destructive/10 text-destructive rounded-lg text-sm">{error}</div>
          )}

          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-1 block">Email</label>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                className="w-full px-4 py-3 border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary"
                placeholder="admin@inkvault.com"
                onKeyDown={e => e.key === "Enter" && handleLogin()}
              />
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">Password</label>
              <div className="relative">
                <input
                  type={showPass ? "text" : "password"}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  className="w-full px-4 py-3 border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary pr-12"
                  placeholder="••••••••"
                  onKeyDown={e => e.key === "Enter" && handleLogin()}
                />
                <button
                  onClick={() => setShowPass(!showPass)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
                >
                  {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
            <button
              onClick={handleLogin}
              disabled={loading}
              className="w-full py-3 bg-primary text-primary-foreground font-medium rounded-lg hover:bg-primary/90 transition-colors disabled:opacity-50"
            >
              {loading ? "Signing in..." : "Sign In"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── BLOG EDITOR ─────────────────────────────────────────────────────────────
function BlogEditor({
  initial, onSave, onCancel
}: {
  initial?: Partial<Article>;
  onSave: (a: Omit<Article, "id" | "createdAt">) => Promise<void>;
  onCancel: () => void;
}) {
  const [form, setForm] = useState<Partial<Article>>({
    title: "", excerpt: "", content: "", category: "Technology",
    tags: [], imageUrl: "", metaTitle: "", metaDescription: "",
    hashtags: [], status: "draft",
    author: { name: "InkVault Editorial", avatarUrl: "" },
    ...initial,
  });
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [saving, setSaving] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);

  const set = (key: keyof Article, val: any) => setForm(f => ({ ...f, [key]: val }));

  const handleAIFill = async () => {
    if (!form.title) { alert("Enter a topic/title first"); return; }
    setAiLoading(true);
    try {
      const blog = await generateBlogFromTopic(form.title, form.category);
      setForm(f => ({
        ...f, ...blog,
        imageUrl: getUnsplashImage(blog.imageQuery),
        readTime: estimateReadTime(blog.content),
        date: new Date().toISOString().split("T")[0],
      }));
    } catch { alert("AI generation failed. Check your API."); }
    setAiLoading(false);
  };

  const handleSave = async () => {
    if (!form.title || !form.content) { alert("Title and content are required"); return; }
    setSaving(true);
    try {
      let imageUrl = form.imageUrl || "";
      if (imageFile) imageUrl = await uploadImage(imageFile);
      await onSave({
        ...form as Article,
        imageUrl,
        readTime: estimateReadTime(form.content || ""),
        date: form.date || new Date().toISOString().split("T")[0],
      });
    } catch (e) { alert("Save failed: " + e); }
    setSaving(false);
  };

  const CATEGORIES = ["Technology", "Lifestyle", "Travel", "Culture", "Business", "Health", "Science", "Finance"];

  return (
    <div className="fixed inset-0 bg-background/95 backdrop-blur-sm z-50 overflow-y-auto">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="font-display text-2xl font-bold">{initial?.id ? "Edit Article" : "New Article"}</h2>
          <div className="flex gap-3">
            <button onClick={onCancel} className="px-4 py-2 border border-border rounded-lg text-sm hover:bg-secondary">
              <X className="w-4 h-4" />
            </button>
            <button
              onClick={handleAIFill}
              disabled={aiLoading}
              className="px-4 py-2 bg-accent text-accent-foreground rounded-lg text-sm font-medium flex items-center gap-2 hover:bg-accent/90 disabled:opacity-50"
            >
              <Zap className="w-4 h-4" />
              {aiLoading ? "AI Writing..." : "AI Generate"}
            </button>
            <button
              onClick={handleSave}
              disabled={saving}
              className="px-6 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium flex items-center gap-2 disabled:opacity-50"
            >
              <Save className="w-4 h-4" />
              {saving ? "Saving..." : "Save"}
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-4">
            <div>
              <label className="text-sm font-medium mb-1 block">Title / Topic *</label>
              <input
                value={form.title}
                onChange={e => set("title", e.target.value)}
                className="w-full px-4 py-3 border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary text-lg font-display"
                placeholder="Enter article title or topic for AI..."
              />
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">Excerpt</label>
              <textarea
                value={form.excerpt}
                onChange={e => set("excerpt", e.target.value)}
                rows={2}
                className="w-full px-4 py-3 border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary resize-none"
                placeholder="Short description (160 chars max)..."
              />
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">Content (HTML) *</label>
              <textarea
                value={form.content}
                onChange={e => set("content", e.target.value)}
                rows={16}
                className="w-full px-4 py-3 border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary resize-none font-mono text-sm"
                placeholder="Full article content (HTML supported)..."
              />
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-1 block">Category</label>
              <select
                value={form.category}
                onChange={e => set("category", e.target.value)}
                className="w-full px-4 py-3 border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary"
              >
                {CATEGORIES.map(c => <option key={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">Status</label>
              <select
                value={form.status}
                onChange={e => set("status", e.target.value as any)}
                className="w-full px-4 py-3 border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary"
              >
                <option value="draft">Draft</option>
                <option value="published">Published</option>
                <option value="scheduled">Scheduled</option>
              </select>
            </div>
            {form.status === "scheduled" && (
              <div>
                <label className="text-sm font-medium mb-1 block">Schedule Date & Time</label>
                <input
                  type="datetime-local"
                  value={form.scheduledAt}
                  onChange={e => set("scheduledAt", e.target.value)}
                  className="w-full px-4 py-3 border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
            )}
            <div>
              <label className="text-sm font-medium mb-1 block">Hero Image URL</label>
              <input
                value={form.imageUrl}
                onChange={e => set("imageUrl", e.target.value)}
                className="w-full px-4 py-3 border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary"
                placeholder="https://images.unsplash.com/..."
              />
              {form.imageUrl && (
                <img src={form.imageUrl} alt="" className="mt-2 w-full h-28 object-cover rounded-lg" />
              )}
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">Upload Image</label>
              <input
                type="file"
                accept="image/*"
                onChange={e => setImageFile(e.target.files?.[0] || null)}
                className="w-full text-sm text-muted-foreground"
              />
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">SEO Meta Title</label>
              <input
                value={form.metaTitle}
                onChange={e => set("metaTitle", e.target.value)}
                className="w-full px-4 py-3 border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary"
                placeholder="SEO title (60 chars max)"
              />
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">SEO Meta Description</label>
              <textarea
                value={form.metaDescription}
                onChange={e => set("metaDescription", e.target.value)}
                rows={2}
                className="w-full px-4 py-3 border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary resize-none"
                placeholder="Meta description (160 chars)"
              />
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">Tags (comma separated)</label>
              <input
                value={(form.tags || []).join(", ")}
                onChange={e => set("tags", e.target.value.split(",").map(t => t.trim()).filter(Boolean))}
                className="w-full px-4 py-3 border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary"
                placeholder="ai, technology, future"
              />
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">Author Name</label>
              <input
                value={form.author?.name}
                onChange={e => set("author", { ...form.author, name: e.target.value })}
                className="w-full px-4 py-3 border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary"
                placeholder="Author name"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── MAIN ADMIN PAGE ─────────────────────────────────────────────────────────
export default function Admin() {
  const [user, setUser] = useState<User | null>(null);
  const [articles, setArticles] = useState<Article[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<Partial<Article> | null>(null);
  const [isNew, setIsNew] = useState(false);
  const [aiRunning, setAiRunning] = useState(false);
  const [aiLog, setAiLog] = useState<string[]>([]);
  const [activeTab, setActiveTab] = useState<"posts" | "ai" | "stats">("posts");

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, u => {
      setUser(u);
      if (u) loadArticles();
      else setLoading(false);
    });
    return unsub;
  }, []);

  const loadArticles = async () => {
    setLoading(true);
    try { setArticles(await getAllArticles()); }
    catch { setArticles([]); }
    setLoading(false);
  };

  const handleSave = async (article: Omit<Article, "id" | "createdAt">) => {
    if (editing?.id) {
      await updateArticle(editing.id, article);
    } else {
      await createArticle(article);
    }
    await loadArticles();
    setEditing(null);
    setIsNew(false);
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Delete this article permanently?")) return;
    await deleteArticle(id);
    await loadArticles();
  };

  const handlePublish = async (article: Article) => {
    await updateArticle(article.id!, { status: "published", date: new Date().toISOString().split("T")[0] });
    await loadArticles();
  };

  const runDailyAI = async () => {
    setAiRunning(true);
    setAiLog(["🤖 Fetching today's trending topics..."]);
    try {
      const topics = await generateDailyTrendingBlogs();
      setAiLog(l => [...l, `✅ Found ${topics.length} trending topics`]);

      for (const { topic, category } of topics) {
        setAiLog(l => [...l, `✍️ Writing: "${topic}"...`]);
        try {
          const blog = await generateBlogFromTopic(topic, category);
          await createArticle({
            ...blog,
            imageUrl: getUnsplashImage(blog.imageQuery),
            readTime: estimateReadTime(blog.content),
            date: new Date().toISOString().split("T")[0],
            status: "published",
            views: 0,
            author: { name: "InkVault Editorial", avatarUrl: "" },
          });
          setAiLog(l => [...l, `✅ Published: "${blog.title}"`]);
        } catch {
          setAiLog(l => [...l, `❌ Failed: "${topic}"`]);
        }
      }
      setAiLog(l => [...l, "🎉 Daily AI publishing complete!"]);
      await loadArticles();
    } catch (e) {
      setAiLog(l => [...l, "❌ Error: " + e]);
    }
    setAiRunning(false);
  };

  if (!user) return <LoginScreen onLogin={setUser} />;

  const published = articles.filter(a => a.status === "published");
  const drafts = articles.filter(a => a.status === "draft");
  const totalViews = articles.reduce((s, a) => s + (a.views || 0), 0);

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Admin — InkVault</title>
        <meta name="robots" content="noindex,nofollow" />
      </Helmet>

      {(editing !== null || isNew) && (
        <BlogEditor
          initial={isNew ? {} : editing!}
          onSave={handleSave}
          onCancel={() => { setEditing(null); setIsNew(false); }}
        />
      )}

      {/* Top bar */}
      <header className="border-b border-border bg-card sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-primary text-primary-foreground p-1.5 rounded-sm">
              <Feather className="w-5 h-5" />
            </div>
            <span className="font-display font-bold text-xl">InkVault Admin</span>
            <span className="px-2 py-0.5 bg-accent/20 text-accent text-xs font-medium rounded-full">Beta</span>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-sm text-muted-foreground hidden sm:block">{user.email}</span>
            <button
              onClick={() => signOut(auth)}
              className="p-2 text-muted-foreground hover:text-foreground hover:bg-muted rounded-lg"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {[
            { label: "Total Posts", value: articles.length, icon: FileText, color: "text-primary" },
            { label: "Published", value: published.length, icon: CheckCircle, color: "text-green-600" },
            { label: "Drafts", value: drafts.length, icon: Clock, color: "text-accent" },
            { label: "Total Views", value: totalViews.toLocaleString(), icon: BarChart2, color: "text-blue-500" },
          ].map(s => (
            <div key={s.label} className="bg-card border border-border rounded-xl p-5">
              <s.icon className={`w-5 h-5 ${s.color} mb-2`} />
              <div className="text-2xl font-bold font-display">{s.value}</div>
              <div className="text-sm text-muted-foreground">{s.label}</div>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div className="flex gap-1 mb-6 bg-muted p-1 rounded-lg w-fit">
          {(["posts", "ai", "stats"] as const).map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 rounded-md text-sm font-medium capitalize transition-colors ${activeTab === tab ? "bg-background shadow-sm text-foreground" : "text-muted-foreground hover:text-foreground"}`}
            >
              {tab === "ai" ? "🤖 AI Publisher" : tab === "stats" ? "📊 Stats" : "📝 Posts"}
            </button>
          ))}
        </div>

        {/* POSTS TAB */}
        {activeTab === "posts" && (
          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-display text-xl font-bold">All Articles</h2>
              <button
                onClick={() => { setIsNew(true); setEditing(null); }}
                className="px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium flex items-center gap-2 hover:bg-primary/90"
              >
                <Plus className="w-4 h-4" /> New Article
              </button>
            </div>

            {loading ? (
              <div className="text-center py-12 text-muted-foreground">Loading articles...</div>
            ) : articles.length === 0 ? (
              <div className="text-center py-12 border border-dashed border-border rounded-xl">
                <FileText className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
                <p className="text-muted-foreground">No articles yet. Create your first one or run AI Publisher.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {articles.map(article => (
                  <div key={article.id} className="bg-card border border-border rounded-xl p-4 flex items-center gap-4 hover:border-primary/30 transition-colors">
                    {article.imageUrl && (
                      <img src={article.imageUrl} alt="" className="w-16 h-16 rounded-lg object-cover shrink-0 hidden sm:block" />
                    )}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1 flex-wrap">
                        <span className={`px-2 py-0.5 text-xs font-medium rounded-full ${
                          article.status === "published" ? "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400" :
                          article.status === "scheduled" ? "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400" :
                          "bg-muted text-muted-foreground"
                        }`}>{article.status}</span>
                        <span className="text-xs text-accent font-medium">{article.category}</span>
                      </div>
                      <h3 className="font-medium line-clamp-1">{article.title}</h3>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        {article.date} · {article.readTime} · {article.views || 0} views
                      </p>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      {article.status === "draft" && (
                        <button
                          onClick={() => handlePublish(article)}
                          className="p-2 text-green-600 hover:bg-green-50 dark:hover:bg-green-900/20 rounded-lg"
                          title="Publish"
                        >
                          <Globe className="w-4 h-4" />
                        </button>
                      )}
                      <button
                        onClick={() => { setEditing(article); setIsNew(false); }}
                        className="p-2 text-muted-foreground hover:text-foreground hover:bg-muted rounded-lg"
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDelete(article.id!)}
                        className="p-2 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-lg"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* AI TAB */}
        {activeTab === "ai" && (
          <div className="max-w-2xl">
            <h2 className="font-display text-xl font-bold mb-2">🤖 AI Auto Publisher</h2>
            <p className="text-muted-foreground mb-6">Click the button below to automatically find today's trending global topics and publish fully written, SEO-optimized blog posts.</p>

            <div className="bg-card border border-border rounded-xl p-6 mb-6">
              <div className="flex items-center gap-3 mb-4">
                <TrendingUp className="w-5 h-5 text-accent" />
                <h3 className="font-medium">Daily Trending Publisher</h3>
              </div>
              <p className="text-sm text-muted-foreground mb-4">
                This will: (1) Ask Claude AI for today's top 5 trending topics, (2) Write full blog posts for each, (3) Auto-add SEO tags, meta descriptions & hashtags, (4) Publish immediately to your site.
              </p>
              <button
                onClick={runDailyAI}
                disabled={aiRunning}
                className="w-full py-3 bg-accent text-accent-foreground font-medium rounded-lg flex items-center justify-center gap-2 hover:bg-accent/90 disabled:opacity-50"
              >
                {aiRunning ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4" />}
                {aiRunning ? "AI is writing & publishing..." : "Run Daily AI Publisher"}
              </button>
            </div>

            {aiLog.length > 0 && (
              <div className="bg-muted rounded-xl p-4 font-mono text-sm space-y-1">
                {aiLog.map((log, i) => (
                  <div key={i} className="text-foreground">{log}</div>
                ))}
              </div>
            )}

            <div className="mt-6 p-4 border border-border rounded-xl bg-card">
              <h3 className="font-medium mb-2 flex items-center gap-2">
                <Calendar className="w-4 h-4 text-primary" /> Schedule Tip
              </h3>
              <p className="text-sm text-muted-foreground">
                For fully automatic daily publishing, set up a cron job or use <strong>GitHub Actions</strong> to call this endpoint every morning at 6 AM. Contact your developer to set this up — no daily manual work needed.
              </p>
            </div>
          </div>
        )}

        {/* STATS TAB */}
        {activeTab === "stats" && (
          <div>
            <h2 className="font-display text-xl font-bold mb-6">📊 Content Overview</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-card border border-border rounded-xl p-6">
                <h3 className="font-medium mb-4">Posts by Category</h3>
                {Object.entries(
                  articles.reduce((acc, a) => ({ ...acc, [a.category]: (acc[a.category] || 0) + 1 }), {} as Record<string, number>)
                ).sort((a, b) => b[1] - a[1]).map(([cat, count]) => (
                  <div key={cat} className="flex items-center gap-3 mb-3">
                    <span className="text-sm font-medium w-24 shrink-0">{cat}</span>
                    <div className="flex-1 bg-muted rounded-full h-2">
                      <div
                        className="bg-primary h-2 rounded-full transition-all"
                        style={{ width: `${(count / Math.max(articles.length, 1)) * 100}%` }}
                      />
                    </div>
                    <span className="text-sm text-muted-foreground w-6 text-right">{count}</span>
                  </div>
                ))}
              </div>
              <div className="bg-card border border-border rounded-xl p-6">
                <h3 className="font-medium mb-4">Top Articles by Views</h3>
                {articles.sort((a, b) => (b.views || 0) - (a.views || 0)).slice(0, 5).map(a => (
                  <div key={a.id} className="flex items-center justify-between mb-3 pb-3 border-b border-border last:border-0 last:mb-0 last:pb-0">
                    <p className="text-sm line-clamp-1 flex-1 mr-2">{a.title}</p>
                    <span className="text-sm font-medium text-accent shrink-0">{(a.views || 0).toLocaleString()}</span>
                  </div>
                ))}
                {articles.length === 0 && <p className="text-sm text-muted-foreground">No articles yet.</p>}
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
