export interface Author {
  name: string;
  avatarUrl: string;
}

export interface Article {
  id: string;
  title: string;
  excerpt: string;
  category: string;
  date: string;
  readTime: string;
  imageUrl: string;
  author: Author;
  rank?: number;
}

export const FEATURED_ARTICLES: Article[] = [
  {
    id: "f1",
    title: "The Architecture of Silence: Finding Focus in a Noisy World",
    excerpt: "In an era defined by constant connectivity, the intentional curation of silence is becoming our most valuable luxury.",
    category: "Culture",
    date: "2024-10-15",
    readTime: "8 min read",
    imageUrl: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=1200",
    author: { name: "Elias Thorne", avatarUrl: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=facearea&facepad=2&w=256&h=256&q=80" },
  },
  {
    id: "f2",
    title: "Synthesizing Nature: The Future of Sustainable Materials",
    excerpt: "How biomimicry and advanced material science are merging to create fabrics that heal the environment rather than harm it.",
    category: "Science",
    date: "2024-10-12",
    readTime: "12 min read",
    imageUrl: "https://images.unsplash.com/photo-1518531933037-91b2f5f229cc?auto=format&fit=crop&q=80&w=1200",
    author: { name: "Dr. Amara Lin", avatarUrl: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=facearea&facepad=2&w=256&h=256&q=80" },
  },
  {
    id: "f3",
    title: "The Renaissance of Slow Travel",
    excerpt: "Moving away from itinerary-driven vacations toward immersive, deliberate journeys that foster genuine connection.",
    category: "Lifestyle",
    date: "2024-10-08",
    readTime: "6 min read",
    imageUrl: "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&q=80&w=1200",
    author: { name: "Julian Vance", avatarUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=facearea&facepad=2&w=256&h=256&q=80" },
  },
];

export const TRENDING_ARTICLES: Article[] = [
  { id: "t1", rank: 1, title: "Decoding the algorithms of human memory", category: "Science", date: "2024-10-18", readTime: "7 min read", imageUrl: "https://images.unsplash.com/photo-1550684848-fac1c5b4e853?auto=format&fit=crop&q=80&w=600", excerpt: "", author: { name: "Sarah Chen", avatarUrl: "" } },
  { id: "t2", rank: 2, title: "The aesthetic principles of modern minimalism", category: "Design", date: "2024-10-17", readTime: "5 min read", imageUrl: "https://images.unsplash.com/photo-1513519245088-0e12902e5a38?auto=format&fit=crop&q=80&w=600", excerpt: "", author: { name: "Marcus Reed", avatarUrl: "" } },
  { id: "t3", rank: 3, title: "Navigating the ethical dilemmas of AI art", category: "Technology", date: "2024-10-16", readTime: "9 min read", imageUrl: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&q=80&w=600", excerpt: "", author: { name: "Elena Rostova", avatarUrl: "" } },
  { id: "t4", rank: 4, title: "The psychology behind our relationship with money", category: "Finance", date: "2024-10-14", readTime: "11 min read", imageUrl: "https://images.unsplash.com/photo-1611024847487-e26177381a3e?auto=format&fit=crop&q=80&w=600", excerpt: "", author: { name: "David Kim", avatarUrl: "" } },
  { id: "t5", rank: 5, title: "Culinary traditions lost and found", category: "Culture", date: "2024-10-13", readTime: "8 min read", imageUrl: "https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&q=80&w=600", excerpt: "", author: { name: "Maria Garcia", avatarUrl: "" } },
];

export const CATEGORIES = [
  "Technology", "Lifestyle", "Travel", "Culture",
  "Business", "Health", "Science", "Finance"
];
